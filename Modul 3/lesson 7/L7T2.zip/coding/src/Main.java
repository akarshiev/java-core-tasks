import uz.pdp.online.tasks.two.Role;
import uz.pdp.online.tasks.two.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class Main {
    public static void main(String[] args) {

        /*
        2-vazifa
        Uy raqamini va shu uyda yashaydigan Userlar listini saqlovchi map yarating
        User classi name, phone, Role Enum fieldlaridan iborat
        Role Enum classi -> GRANDPA, GRANDMA, FATHER, MOTHER ,CHILD qiymatlardan iborat
        Mapni elementlarini "uy raqami va u uyda yashovchi odamlar"
        ko'rinishida ekranga chiqaring
        */

        Map<Integer, List<User>> homeMap = new HashMap<>();

        List<User> firstHomeUsers = new ArrayList<>();
        firstHomeUsers.add(new User("Abdulla", "983475343", Role.GRANDPA));
        firstHomeUsers.add(new User("Durdona", "983475343", Role.GRANDMA));
        firstHomeUsers.add(new User("Akmal", "987864456", Role.FATHER));
        firstHomeUsers.add(new User("Nigora", "765784579", Role.MOTHER));
        firstHomeUsers.add(new User("Muxlisa", "983475343", Role.CHILD));

        homeMap.put(15, firstHomeUsers);


        for (Map.Entry<Integer, List<User>> entry : homeMap.entrySet()) {
            System.out.printf("""
                    Uy raqami: %d
                    Oila a'zolar:
                    %s
                    """.formatted(entry.getKey(), entry.getValue()));
        }
    }
}