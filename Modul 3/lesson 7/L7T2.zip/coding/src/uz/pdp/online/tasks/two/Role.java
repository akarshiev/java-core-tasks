package uz.pdp.online.tasks.two;

public enum Role {
    GRANDPA, GRANDMA, FATHER, MOTHER, CHILD
}
