import uz.pdp.online.lesson2.task.two.*;

public class Main {
    public static void main(String[] args) {
        Cat cat = new Cat("Mushuk");
        AnimalHouse<Cat> catAnimalHouse = new AnimalHouse<>(cat);
        catAnimalHouse.checkResidentSound();

        System.out.println("---");

        Dog dog = new Dog("Kuchuk");
        AnimalHouse<Dog> dogAnimalHouse = new AnimalHouse<>(dog);
        dogAnimalHouse.checkResidentSound();

        System.out.println("---");

        AnimalHouse<Animal> oddiyHayvonUyi = new AnimalHouse<>(new Sheep("Qo'zi"));
        oddiyHayvonUyi.checkResidentSound();

        System.out.println("---");

        oddiyHayvonUyi.setResident(new Horse("Ot"));
        oddiyHayvonUyi.checkResidentSound();
    }
}