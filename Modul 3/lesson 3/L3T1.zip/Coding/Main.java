import java.util.ArrayList;
import java.util.List;
import java.util.Random;

class Main {
    public static void main() {
        List<Integer> nums = new ArrayList<Integer>(30);

        Random random = new Random();
        int min = 0;
        int max = 100;

        for (int i = 0; i < 30; i++) {
            int randomNum = random.nextInt(max - min + 1) + min;
            nums.add(randomNum);
        }

        System.out.println(nums);
        int randomIndex = random.nextInt(nums.size());
        nums.remove(randomIndex);
        System.out.println("O'chiriladigan indeks raqam: " + randomIndex);
        System.out.println("O'chiriladigan raqam: " + nums.get(randomIndex));
        nums.remove(randomIndex);
        System.out.println("nums = " + nums);

    }
}
