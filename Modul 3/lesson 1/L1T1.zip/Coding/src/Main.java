import uz.pdp.online.modul3.task.one.ProgrammingLanguage;

public class Main {
    public static void main(String[] args) {
        ProgrammingLanguage pl = new ProgrammingLanguage(null, null, null);

        try {
            System.out.println(pl.Name.length());
        } catch (NullPointerException e) {
            System.out.println("Something went wrong");
        }
    }
}
