import uz.pdp.online.modul3.task.two.NoFoundNumberException;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] array = {5, 10, 15, 20, 25, 30, 35, 40, 45, 50};

        try {
            System.out.print("1 dan 10 gacha index kiriting: ");
            int index = scanner.nextInt();

            if (index < 1 || index > 10) {
                throw new NoFoundNumberException("Index 1 dan 10 gacha bo'lishi shart!");
            }

            System.out.println("Natija: " + array[index - 1]);

        } catch (NoFoundNumberException e) {
            System.out.println("Xatolik: " + e.getMessage());
        }
    }
}
