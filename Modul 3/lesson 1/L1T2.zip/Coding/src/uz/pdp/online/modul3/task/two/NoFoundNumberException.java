package uz.pdp.online.modul3.task.two;

public class NoFoundNumberException extends Exception {
    public NoFoundNumberException(String message) {
        super(message);
    }
}
