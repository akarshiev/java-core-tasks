package uz.pdp.online.modul3.task.three;

public class RangCantBeBlankException extends RuntimeException {
    public RangCantBeBlankException(String message) {
        super(message);
    }
}
