package uz.pdp.online.modul3.task.three;

public class Home {
    public int qavat;
    public String rangi;
    public int roomCount;
    public String personName;

    public Home(int qavat, String rangi, int roomCount, String personName) {

        if (qavat < 0) {
            throw new QavatCantBeLessThanZeroException("Qavat 0 dan kichik bo'lmasligi kerak!");
        }

        if (rangi == null || rangi.isBlank()) {
            throw new RangCantBeBlankException("Rangi null yoki bo'sh bo'lmasligi kerak!");
        }

        if (roomCount < 10) {
            throw new RoomCountCantBeLessThanTenException("Room Count 10 dan kichik bo'lmasligi kerak!");
        }

        if (personName == null || personName.isBlank()) {
            throw new PersonNameCantBeBlankException("Person name bo'sh bo'lmasligi kerak!");
        }

        this.qavat = qavat;
        this.rangi = rangi;
        this.roomCount = roomCount;
        this.personName = personName;
    }
}
