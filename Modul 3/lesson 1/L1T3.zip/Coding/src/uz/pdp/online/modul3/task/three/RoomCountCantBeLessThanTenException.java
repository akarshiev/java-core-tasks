package uz.pdp.online.modul3.task.three;

public class RoomCountCantBeLessThanTenException extends RuntimeException {
    public RoomCountCantBeLessThanTenException(String message) {
        super(message);
    }
}
