package uz.pdp.online.modul3.task.one;

public class ProgrammingLanguage {
    public String Name;
    public String owner;
    public String releaseDate;

    public ProgrammingLanguage(String Name, String owner, String releaseDate) {
        this.Name = Name;
        this.owner = owner;
        this.releaseDate = releaseDate;
    }
}
