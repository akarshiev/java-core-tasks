package uz.pdp.online.modul3.task.three;

public class PersonNameCantBeBlankException extends RuntimeException {
    public PersonNameCantBeBlankException(String message) {
        super(message);
    }
}
