package uz.pdp.online.modul3.task.three;

public class QavatCantBeLessThanZeroException extends RuntimeException {
    public QavatCantBeLessThanZeroException(String message) {
        super(message);
    }
}
