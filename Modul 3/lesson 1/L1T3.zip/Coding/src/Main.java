import uz.pdp.online.modul3.task.three.*;

public class Main {
    public static void main(String[] args) {

        try {
            Home home = new Home(0, null, 7, "");
        } catch (QavatCantBeLessThanZeroException |
                 RangCantBeBlankException |
                 RoomCountCantBeLessThanTenException |
                 PersonNameCantBeBlankException e) {
            System.out.println("Xatolik: " + e.getMessage());
        }
    }
}
