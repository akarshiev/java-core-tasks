import java.util.LinkedList;

public class Main {
    public static void main() {
        LinkedList<String> firstList = new LinkedList<>();
        firstList.add("Atamjon");
        firstList.add("Sanjar");
        firstList.add("Aly");
        firstList.add("Samandar");
        firstList.add("Sardor");
        firstList.add("Ilyos");
        firstList.add("Islom");
        firstList.add("Abduhalil");
        firstList.add("Asilbek");
        firstList.add("Jonibek");

        LinkedList<String> secondList = new LinkedList<>();
        secondList.add("Diyora");
        secondList.add("Nigora");
        secondList.add("Farzona");
        secondList.add("Sevinch");
        secondList.add("Muxlisa");

        firstList.addAll(secondList);

        firstList.addFirst("Abdukarim");
        firstList.addLast("Abdukarim");

        firstList.forEach(System.out::println);
    }
}
