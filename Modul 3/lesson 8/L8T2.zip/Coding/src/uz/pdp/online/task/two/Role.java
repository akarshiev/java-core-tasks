package uz.pdp.online.task.two;

public enum Role {
    FATHER, MOTHER, CHILD
}
