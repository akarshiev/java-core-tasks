import uz.pdp.online.task.one.Car;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class Main {
    public static void main(String[] args) {
        ArrayList<Car> cars = new ArrayList<>();
        cars.add(new Car("BMW", "White", "BMW X7"));
        cars.add(new Car("Tesla", "Black", "Model X"));
        cars.add(new Car("Li", "White", "L9"));

        //  cars.forEach(System.out::println);

        System.out.println("--- Iterator Print ---");
        Iterator<Car> carIterator = cars.iterator();
        while (carIterator.hasNext()) {
            String car = String.valueOf(carIterator.next());
            System.out.println(car);
        }

        System.out.println("\n--- List Iterator Print ---");
        ListIterator<Car> carListIterator = cars.listIterator(cars.size());

        while (carListIterator.hasPrevious()) {
            String car = String.valueOf(carListIterator.previous());
            System.out.println(car);
        }
    }
}
