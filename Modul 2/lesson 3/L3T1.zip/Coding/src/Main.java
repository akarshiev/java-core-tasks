import uz.pdp.iPhone13;
import uz.pdp.iPhone14;
import uz.pdp.sub_package.Redmi;
import uz.pdp.sub_package.Samsung;

public class Main {
    public static void main(String[] args) {
        iPhone14 iphone14 = new iPhone14(650);
        iphone14.info();
        iPhone13 iphone13 = new iPhone13(490);
        iphone13.info();

        Samsung samsung = new Samsung("Samsung S24 Ultra", 1200);
        samsung.info();

        Redmi redmi = new Redmi("Redmi Note 13", 350);
        redmi.info();
    }
}
