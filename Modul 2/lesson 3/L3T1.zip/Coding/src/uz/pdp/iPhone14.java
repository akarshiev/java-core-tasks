package uz.pdp;

import uz.pdp.sub_package.iPhone;

public class iPhone14 extends iPhone {
    public iPhone14(double price) {
        super("iPhone 14", price);
    }
}
