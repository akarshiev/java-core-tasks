package uz.pdp.super_package;

public class Phone {
    protected String model;
    protected double price;

    public void info() {
        System.out.println("Model: " + model + ", Price: $" + price);
    }
}
