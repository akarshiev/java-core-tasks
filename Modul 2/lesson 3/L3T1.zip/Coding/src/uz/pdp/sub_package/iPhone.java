package uz.pdp.sub_package;
import uz.pdp.super_package.Phone;

public class iPhone extends Phone {
    protected String osVersion = "iOS";

    public iPhone(String model, double price) {
        this.model = model;
        this.price = price;
    }

    public void useFaceID() {
        System.out.println(model + " using Face ID...");
    }
}
