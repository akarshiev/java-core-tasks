package uz.pdp.sub_package;

import uz.pdp.super_package.Phone;

public class Redmi extends Phone {
    public Redmi(String model, double price) {
        this.model = model;
        this.price = price;
    }
}
