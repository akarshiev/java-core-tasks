package uz.pdp.sub_package;

import uz.pdp.super_package.Phone;

public class Samsung extends Phone {
    public Samsung(String model, double price) {
        this.model = model;
        this.price = price;
    }
}
