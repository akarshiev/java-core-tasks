package uz.pdp;

import uz.pdp.sub_package.iPhone;

public class iPhone13 extends iPhone {
    public iPhone13(double price) {
        super("iPhone 13", price);
    }

    public void cinematicMode() {
        System.out.println(model + " supports Cinematic Mode.");
    }
}
