import com.pdp.online.task.Phone;
import com.pdp.online.task.Student;

public class Main {
    public static void main(String[] args) {

        Phone iphone = new Phone("iPhone 14", 256, "Black");
        Phone samsung = new Phone("Samsung S23", 128, "Silver");

        Student[] students = {
                new Student("Abdukarim", "998901111111", "1234", "998909999999", "21A", iphone),
                new Student("Atamjon", "998902222222", "abcd", "998908888888", "22B", samsung),
                new Student("Aly", "998903333333", "qwerty", "998907777777", "23C", iphone)
        };

        for (Student s : students) {
            s.info();
        }

        System.out.println("\n--- Parolni yangilash ---");

        resetPassword(students, "998901111111", "1234", "newpass123");
        resetPassword(students, "998902222222", "xato", "valinew");
    }

    public static void resetPassword(Student[] students, String phone, String oldPassword, String newPassword) {
        boolean found = false;

        for (Student s : students) {
            if (s.getPhone().equals(phone) && s.getPassword().equals(oldPassword)) {
                s.changePassword(oldPassword, newPassword);
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Student topilmadi yoki parol noto'g'ri");
        }
    }
}
