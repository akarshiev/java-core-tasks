package com.pdp.online.task;

public class Phone {
    private String name;
    private int storage;
    private String color;

    public Phone(String name, int storage, String color) {
        this.name = name;
        this.storage = storage;
        this.color = color;
    }

    public void info() {
        System.out.println("Phone: " + name + ", " + storage + "GB, " + color);
    }

    public String getName() {
        return name;
    }
}
