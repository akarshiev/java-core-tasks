package com.pdp.online.task;
import com.pdp.online.task.person.Person;

public class Teacher extends Person {
    private final Subject subject;
    private double salary;

    public Teacher(String name, String phone, String password, Subject subject, double salary) {
        super(name, phone, password);
        this.subject = subject;
        this.salary = salary;
    }

    public void info() {
        System.out.println("Teacher: " + name + ", Subject: " + subject.getName() + ", Salary: " + salary);
    }
}
