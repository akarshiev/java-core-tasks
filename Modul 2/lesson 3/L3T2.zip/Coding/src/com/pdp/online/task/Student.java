package com.pdp.online.task;

import com.pdp.online.task.person.Person;

public class Student extends Person {
    private String parentNumber;
    private String schoolNumber;
    private Phone phone;

    public Student(String name, String phone, String password,
                   String parentNumber, String schoolNumber, Phone studentPhone) {
        super(name, phone, password);
        this.parentNumber = parentNumber;
        this.schoolNumber = schoolNumber;
        this.phone = studentPhone;
    }

    public void call(String number) {
        System.out.println(name + " is calling " + number + " using " + phone.getName());
    }

    public void info() {
        System.out.println("Student: " + name + ", School No: " + schoolNumber);
        phone.info();
    }
}
