package com.pdp.online.task.person;

public class Person {
    protected String name;
    protected String phone;
    private String password;

    public Person(String name, String phone, String password) {
        this.name = name;
        this.phone = phone;
        this.password = password;
    }

    public boolean changePassword(String oldPassword, String newPassword) {
        if (this.password.equals(oldPassword)) {
            this.password = newPassword;
            System.out.println(name + " parol o'zgartirildi");
            return true;
        } else {
            System.out.println(name + " eski parol noto'g'ri");
            return false;
        }
    }

    public String getPhone() {
        return phone;
    }

    public String getPassword() {
        return password;
    }
}
