package com.pdp.online.task;

public final class Subject {
    private String name;
    private int classNumber;

    public Subject(String name, int classNumber) {
        this.name = name;
        this.classNumber = classNumber;
    }

    public String getName() {
        return name;
    }

    public int getClassNumber() {
        return classNumber;
    }

    public void info() {
        System.out.println("Subject: " + name + " (Class " + classNumber + ")");
    }
}
