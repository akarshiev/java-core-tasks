import com.pdp.online.task.two.Application;

public class Main {
    public static void main(String[] args) {
        Application app = Application.getInstance();
        app.run();
    }
}
