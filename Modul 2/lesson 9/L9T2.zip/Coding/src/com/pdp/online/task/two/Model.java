package com.pdp.online.task.two;

public enum Model {
    IPHONE, SAMSUNG, REDMI
}

