package com.pdp.online.task.one;

public enum Gender {
    MALE, FEMALE
}
