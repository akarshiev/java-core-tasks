package com.pdp.online.task.one;

public enum Size {
    S, M, X, XL
}
