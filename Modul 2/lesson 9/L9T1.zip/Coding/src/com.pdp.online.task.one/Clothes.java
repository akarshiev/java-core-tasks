package com.pdp.online.task.one;

public class Clothes {

    private String color;
    private Size size;

    public Clothes(String color, Size size) {
        this.color = color;
        this.size = size;
    }

    @Override
    public String toString() {
        return "Clothes{color='" + color + "', size=" + size + '}';
    }
}
