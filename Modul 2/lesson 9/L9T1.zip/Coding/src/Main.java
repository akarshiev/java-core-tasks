import com.pdp.online.task.one.*;

public class Main {
    public static void main(String[] args) {

        var c1 = new Clothes("Red", Size.M);
        var c2 = new Clothes("Black", Size.XL);
        var c3 = new Clothes("White", Size.S);
        var c4 = new Clothes("Blue", Size.X);

        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);
        System.out.println(c4);
    }
}
