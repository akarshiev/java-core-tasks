package com.pdp.online.task.one;

public abstract class Person {

    public String name;
    public String phone;

    public Person(String name, String phone) {
        this.name = name;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public abstract void speak();

    public abstract void walk();
}
