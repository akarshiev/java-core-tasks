package com.pdp.online.task.two;

public class Cat implements Animal, Pet {

    @Override
    public void eat() {
        System.out.println("Cat eats fish");
    }

    @Override
    public void live() {
        System.out.println("Cat lives with humans");
    }

    @Override
    public void play() {
        System.out.println("Cat is playing with a mouse");
    }
}
