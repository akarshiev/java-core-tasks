package com.pdp.online.task;

public class Parent extends Person {
    public Parent(String name, String phone) {
        super(name, phone);
    }

    @Override
    public void speak() {
        System.out.println(name + " is speaking");
    }

    @Override
    public void walk() {
        System.out.println(name + " isn't walking");
    }
}
