import com.pdp.online.task.*;

class Main {
    public static void main(String[] args) {
        Person student = new Student("Abdukarim", "0009299921");
        System.out.println("Student name: " + student.getName());
        System.out.println("Student phone: " + student.getPhone());
        System.out.println();
        student.walk();
        student.speak();
    }
}