import com.pdp.online.task.three.*;

public class Main {
    public static void main(String[] args) {

        Malibu malibu = new Malibu();
        malibu.drive();

        Spark spark = new Spark();
        spark.drive();

        WashingMachine washingMachine = new WashingMachine();
        washingMachine.start();

        Television tv = new Television();
        tv.start();
    }
}
