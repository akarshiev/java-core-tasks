package com.pdp.online.task.three;

public abstract class Equipment implements Texnika {
    public abstract void start();
}
