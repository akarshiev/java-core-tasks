package com.pdp.online.task.three;

public class WashingMachine extends Equipment {
    @Override
    public void start() {
        System.out.println("Washing machine is washing");
    }
}
