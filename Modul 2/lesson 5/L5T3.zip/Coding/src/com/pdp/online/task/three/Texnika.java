package com.pdp.online.task.three;

public interface Texnika {
}
