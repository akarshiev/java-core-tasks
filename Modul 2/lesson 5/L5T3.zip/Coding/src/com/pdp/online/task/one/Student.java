package com.pdp.online.task.one;

public class Student extends Person {

    public Student(String name, String phone) {
        super(name, phone);
    }

    @Override
    public void speak() {
        System.out.println(name + " is not speaking");
    }

    @Override
    public void walk() {
        System.out.println(name + " is walking");
    }
}
