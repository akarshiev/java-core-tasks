package com.pdp.online.task.two;

public class Dog implements Animal, Pet {

    @Override
    public void eat() {
        System.out.println("Dog eats meat");
    }

    @Override
    public void live() {
        System.out.println("Dog lives with humans");
    }

    @Override
    public void play() {
        System.out.println("Dog is playing with a ball");
    }
}
