package com.pdp.online.task.three;

public class Television extends Equipment {
    @Override
    public void start() {
        System.out.println("Tv is turn on");
    }
}
