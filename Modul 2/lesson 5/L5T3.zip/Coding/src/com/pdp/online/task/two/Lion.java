package com.pdp.online.task.two;

public class Lion implements Animal, Wild {

    @Override
    public void eat() {
        System.out.println("Lion eats meat");
    }

    @Override
    public void live() {
        System.out.println("Lion lives in the wild");
    }

    @Override
    public void hunt() {
        System.out.println("Lion is hunting");
    }
}
