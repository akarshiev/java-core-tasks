package com.pdp.online.task.three;

public class Malibu extends Vehicle {

    @Override
    public void drive() {
        System.out.println("Malibu is driving");
    }
}
