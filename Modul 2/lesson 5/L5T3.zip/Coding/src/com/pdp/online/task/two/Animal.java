package com.pdp.online.task.two;

public interface Animal {
    void eat();
    void live();
}


