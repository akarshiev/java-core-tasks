package com.pdp.online.task.three;

public class Spark extends Vehicle {
    @Override
    public void drive() {
        System.out.println("Spark is driving");
    }
}
