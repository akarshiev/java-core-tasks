package com.pdp.online.task.two;

public interface Wild {
    void hunt();
}
