package com.pdp.online.task.three;

public abstract class Vehicle implements Texnika {
    public abstract void drive();
}
