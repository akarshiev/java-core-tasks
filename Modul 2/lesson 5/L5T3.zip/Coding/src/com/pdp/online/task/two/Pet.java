package com.pdp.online.task.two;

public interface Pet {
    void play();
}
