package com.pdp.online.quiz.model;

public class User {
}
