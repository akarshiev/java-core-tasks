package com.pdp.online.quiz.core;

/**
 * Contract to show quiz items

 */

public interface Quiz {
    void show();
}
