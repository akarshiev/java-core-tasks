package com.pdp.online.quiz.model;

/**
 * Role of a user
 */

public enum Role {
    TEACHER,
    STUDENT
}
