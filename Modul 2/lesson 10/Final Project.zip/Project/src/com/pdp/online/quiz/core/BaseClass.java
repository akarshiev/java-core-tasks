package com.pdp.online.quiz.core;

/**
 * Marker interface for base classes
 */

public interface BaseClass {
}
