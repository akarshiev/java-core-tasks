package com.pdp.online.task.two;

public class User {

	// Ism, Familya, PhoneNumber, Age va isMale fieldlari bo'lgan User classini
	// encapsulation prinsipi asosida yarating

	private String firstName;
	private String lastName;
	private String PhoneNumber;
	private int Age;
	private String isMale;

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public void setAge(int age) {
		Age = age;
	}

	public void setMale(String isMale) {
		this.isMale = isMale;
	}

	// "Ismi: Familya Ism, yoshi: age, telefoni raqami: phoneNumber, Jinsi: isMale"
	// ko'rinishida consolega chop etilsin.

	public void print() {
		System.out.printf("""
				Ismi: %s %s
				yoshi: %d
				telefon raqami: %s
				jinsi: %s
				""", firstName, lastName, Age, PhoneNumber, isMale);
	}
}
