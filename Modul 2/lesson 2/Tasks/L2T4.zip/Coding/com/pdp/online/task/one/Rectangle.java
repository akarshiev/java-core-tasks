package com.pdp.online.task.one;

public class Rectangle {

	private int width;
	private int height;
	private int result;

	public void setWidth(int width) {
		this.width = width;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public void calculate() {
		result = width * height;
	}

	public void printResult() {
		System.out.println(width + " * " + height + " = " + result);
	}

}
