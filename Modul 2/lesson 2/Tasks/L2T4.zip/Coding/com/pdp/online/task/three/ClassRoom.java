package com.pdp.online.task.three;

public class ClassRoom {

	// roomNumber,teacherName,teacherPhoneNumber, studentName
	// (bittadan ko'p bo'ladi) va studentCount fieldlari bo'lgan
	// ClassRoom classini encapsulation prinsipi asosida yarating
	// Malumotlar console orqali kiritilsin.
	// roomnumber, teacherNmae va studentlarini chop eting

	private int roomNumber;
	private String teacherName;
	private String teacherPhoneNumber;
	private String[] studentNames;
	private int studentCount;

	public ClassRoom(int studentCount) {
		this.studentCount = studentCount;
		this.studentNames = new String[studentCount];
	}

	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public void setTeacherPhoneNumber(String teacherPhoneNumber) {
		this.teacherPhoneNumber = teacherPhoneNumber;
	}

	public void setStudentName(int index, String name) {
		this.studentNames[index] = name;
	}

	public int getRoomNumber() {
		return roomNumber;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public String getTeacherPhoneNumber() {
		return teacherPhoneNumber;
	}

	public String[] getStudentNames() {
		return studentNames;
	}

	public void printInfo() {
		System.out.println("\n-- ClassRom info --");
		System.out.println("Room Number: " + roomNumber);
		System.out.println("Teacher: " + teacherName);
		System.out.println("Phone: " + teacherPhoneNumber);
		System.out.println("Students:");

		for (String student : studentNames) {
			System.out.println(student);
		}

		System.out.println("Total Students: " + studentCount);
	}
}
