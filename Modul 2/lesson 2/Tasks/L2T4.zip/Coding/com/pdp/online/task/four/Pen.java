package com.pdp.online.task.four;

public class Pen {

	// miqdor,clicked va oneLetter fieldlari bo'lgan Pen Classi encapsulation
	// prinsplariga asoslangan holda yaratilsin.
	// Miqdor -> ruchkani siyohi qanchaligi
	// Clicked -> ruchka bosilganmi yoki yo'q
	// OneLetter -> bitta harf uchun qancha siyoh ketishi
	// write methodi orqali ruchka yoshishni boshlasin. Katta harf yozilganda
	// kichkina harfga qaraganda 2 barobar siyoh sarflasin, agarda bo'sh joy
	// keladigan bo'lsa siyoh sarflanmasin. Agar siyoh tugasa ruchka yozishdan
	// to'xtasin va yozilgan text consolega chiqarilsin.

	private double miqdor;
	private boolean clicked;
	private double oneLetter;

	public Pen(double miqdor, double oneLetter) {
		this.miqdor = miqdor;
		this.oneLetter = oneLetter;
		this.clicked = false;
	}

	public double getMiqdor() {
		return miqdor;
	}

	public void setMiqdor(double miqdor) {
		this.miqdor = miqdor;
	}

	public boolean isClicked() {
		return clicked;
	}

	public void setClicked(boolean clicked) {
		this.clicked = clicked;
	}

	public double getOneLetter() {
		return oneLetter;
	}

	public void setOneLetter(double oneLetter) {
		this.oneLetter = oneLetter;
	}

	public void click() {
		clicked = !clicked;
		System.out.println("Ruchka holati: " + (clicked ? "Bosilgan" : "Bosilmagan"));
	}

	public void write(String text) {
		if (!clicked) {
			System.out.println("Ruchka bosilmagan");
			return;
		}

		String writtenText = "";

		for (int i = 0; i < text.length(); i++) {
			char c = text.charAt(i);

			if (c == ' ') {
				writtenText += c;
				continue;
			}

			double inkNeeded = Character.isUpperCase(c) ? oneLetter * 2 : oneLetter;

			if (miqdor >= inkNeeded) {
				miqdor -= inkNeeded;
				writtenText += c;
			} else {
				System.out.println("Siyoh tugadi");
				break;
			}
		}

		System.out.println("Yozilgan matn: " + writtenText);
		System.out.println("Qolgan siyoh: " + miqdor);
	}
}
