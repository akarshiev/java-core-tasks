
// import com.pdp.online.task.one.Rectangle;
// import com.pdp.online.task.two.User;
// import com.pdp.online.task.three.ClassRoom;
import com.pdp.online.task.four.Pen;

public class Main {

	public static void main(String[] args) {

		Pen pen = new Pen(10, 0.5);
		pen.click();
		pen.write("Hello Worldddd");

		// Scanner sc = new Scanner(System.in);

		// System.out.print("Room number: ");
		// int room = sc.nextInt();
		// sc.nextLine();

		// System.out.print("Teacher name: ");
		// String teacher = sc.nextLine();

		// System.out.print("Teacher phone: ");
		// String phone = sc.nextLine();

		// System.out.print("Nechta student bor: ");
		// int count = sc.nextInt();
		// sc.nextLine();

		// ClassRoom classRoom = new ClassRoom(count);
		// classRoom.setRoomNumber(room);
		// classRoom.setTeacherName(teacher);
		// classRoom.setTeacherPhoneNumber(phone);

		// for (int i = 0; i < count; i++) {
		// System.out.print((i + 1) + "-student nomi: ");
		// String name = sc.nextLine();
		// classRoom.setStudentName(i, name);
		// }

		// classRoom.printInfo();

		// User user1 = new User();
		// user1.setFirstName("Abdukarim");
		// user1.setLastName("Karshiev");
		// user1.setAge(20);
		// user1.setPhoneNumber("935782021");
		// user1.setMale("Erkak");

		// user1.print();

		// Rectangle rectangle = new Rectangle();
		// rectangle.setWidth(5);
		// rectangle.setHeight(3);
		// rectangle.calculate();
		// rectangle.printResult();

	}
}