import com.pdp.online.task.one.Rectangle;

public class Main {

	public static void main(String[] args) {
		Rectangle rectangle = new Rectangle();
		rectangle.setWidth(5);
		rectangle.setHeight(3);
		rectangle.calculate();
		rectangle.printResult();
	}
}