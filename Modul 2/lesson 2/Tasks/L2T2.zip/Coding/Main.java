import com.pdp.online.task.two.User;

public class Main {

	public static void main(String[] args) {

		User user1 = new User();
		user1.setFirstName("Abdukarim");
		user1.setLastName("Karshiev");
		user1.setAge(20);
		user1.setPhoneNumber("935782021");
		user1.setMale("Erkak");

		user1.print();

		// Rectangle rectangle = new Rectangle();
		// rectangle.setWidth(5);
		// rectangle.setHeight(3);
		// rectangle.calculate();
		// rectangle.printResult();

	}
}