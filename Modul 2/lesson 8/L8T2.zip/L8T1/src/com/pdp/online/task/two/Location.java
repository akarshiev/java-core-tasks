package com.pdp.online.task.two;

public record Location(String regionName, String districtName, int homeNumber) {
}
