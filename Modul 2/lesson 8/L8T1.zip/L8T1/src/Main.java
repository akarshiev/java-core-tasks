import com.pdp.online.task.one.Book;

public class Main {
    public static void main(String[] args) {

        Book book1 = new Book("Clean Code", "Robert Martin", 464, 45_000);

        System.out.println("Book 1");
        System.out.println(book1);

        Book book2 = new Book("", "", -5, 30_000);

        System.out.println("Book 2");
        System.out.println(book2);
    }
}
