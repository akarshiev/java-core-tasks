package com.pdp.online.task.three;

public class Technique {
    public void work() {
        System.out.println("It is working");
    }

    public void turnOn() {
        System.out.println("Turned On");
    }

    public void turnOff() {
        System.out.println("Turned Off");
    }
}
