package com.pdp.online.task.four;

public class Dog extends Animal {
    @Override
    public void live() {
        System.out.println("Dog lives in garden");
    }

    @Override
    public void eat() {
        System.out.println("Dog eats meat");
    }
}
