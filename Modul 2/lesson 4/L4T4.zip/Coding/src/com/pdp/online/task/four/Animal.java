package com.pdp.online.task.four;

public class Animal {
    public void live() {
        System.out.println("Animal is living");
    }

    public void eat() {
        System.out.println("Animal is eating");
    }
}
