package com.pdp.online.task.three;

public class Televizor extends Technique {
    @Override
    public void work(){
        System.out.println("TV is working");
    }
}
