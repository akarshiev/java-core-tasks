package com.pdp.online.task.three;

public class Mashina extends Technique {
    @Override
    public void work() {
        System.out.println("Mashina is working");
    }
}
