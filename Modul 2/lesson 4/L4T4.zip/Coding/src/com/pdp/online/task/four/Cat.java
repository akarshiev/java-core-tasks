package com.pdp.online.task.four;

public class Cat extends Animal {
    @Override
    public void live() {
        System.out.println("Cat lives in house");
    }

    @Override
    public void eat() {
        System.out.println("Cat eats fish");
    }
}
