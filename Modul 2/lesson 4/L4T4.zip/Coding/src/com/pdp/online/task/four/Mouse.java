package com.pdp.online.task.four;

public class Mouse extends Animal {
    @Override
    public void live() {
        System.out.println("Mouse lives in small holes");
    }

    @Override
    public void eat() {
        System.out.println("Mouse eats cheese");
    }
}
