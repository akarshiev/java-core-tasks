import com.pdp.online.task.four.*;

public class Main {
    public static void main(String[] args) {

        Animal cat = new Cat();
        Animal dog = new Dog();
        Animal mouse = new Mouse();

        cat.live();
        cat.eat();

        dog.live();
        dog.eat();

        mouse.live();
        mouse.eat();
    }
}
