import com.pdp.online.task.three.*;

public class Main {
    public static void main(String[] args) {
        Televizor tv = new Televizor();
        tv.work();

        Mashina mashina = new Mashina();
        mashina.work();

        Telefon telefon = new Telefon();
        telefon.work();
    }
}
