package com.pdp.online.task.three;

public class Telefon extends Technique {
    @Override
    public void work(){
        System.out.println("Telefon is working");
    }
}
