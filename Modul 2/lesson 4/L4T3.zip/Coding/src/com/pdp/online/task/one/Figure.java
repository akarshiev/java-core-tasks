package com.pdp.online.task.one;

public class Figure {
    public double premetr(double a, double b) {
        return 2 * (a + b);
    }

    public double premetr(double a, double b, double c) {
        return a + b + c;
    }

    public double premetr(double a) {
        return 4 * a;
    }

    public double premetr(double a, double b, double c, double d, double f) {
        return a + b + c + d + f;
    }

}
