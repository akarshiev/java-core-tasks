package com.pdp.online.task.two;

public class MyMath {

    public String add(String str, int a) {
        return str + a;
    }

    public String add(String str, double a) {
        return str + a;
    }

    public String add(String str, String str2) {
        return str + str2;
    }

    public int add(int a, int b) {
        return a + b;
    }

    public double add(double a, double b) {
        return a + b;
    }

    public double add(double a, int b) {
        return a + b;
    }
}
