import com.pdp.online.task.two.MyMath;

class Main {
    static void main(String[] args) {
        MyMath myMath = new MyMath();

        //matn va sonni ni qo'shadigan
        //matn va double ni qo'shadigan
        //matn va matn ni qo'shadigan
        //son va sonni ni qo'shadigan
        //double va double ni qo'shadigan
        //double va sonni ni qo'shadigan

        System.out.println("matn va sonni ni qo'shadigan: " + myMath.add("str ", 5));
        System.out.println("matn va double ni qo'shadigan: " + myMath.add("str ", 5.5));
        System.out.println("matn va matn ni qo'shadigan: " + myMath.add("str ", "str2"));
        System.out.println("son va sonni ni qo'shadigan: " + myMath.add(34, 50));
        System.out.println("double va double ni qo'shadigan: " + myMath.add(45.7, 34.5));
        System.out.println("double va sonni ni qo'shadigan: " + myMath.add(34.8, 30));


//        Figure figure = new Figure();
//
//        System.out.println("To'g'ri to'rburchak perimetri: " + figure.premetr(2.3, 3));
//        System.out.println("Uchburchak perimetri: " + figure.premetr(3, 4, 5));
//        System.out.println("Kvadrat perimetri: " + figure.premetr(4));
//        System.out.println("Beshburchak perimetri: " + figure.premetr(2, 3, 4, 5, 6));
    }
}