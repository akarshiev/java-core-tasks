import com.pdp.online.task.Figure;

class Main {
    static void main(String[] args) {
        Figure figure = new Figure();

        System.out.println("To'g'ri to'rburchak perimetri: " + figure.premetr(2.3, 3));
        System.out.println("Uchburchak perimetri: " + figure.premetr(3, 4, 5));
        System.out.println("Kvadrat perimetri: " + figure.premetr(4));
        System.out.println("Beshburchak perimetri: " + figure.premetr(2, 3, 4, 5, 6));
    }
}